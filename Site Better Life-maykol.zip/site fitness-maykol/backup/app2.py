from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__, template_folder='template', static_folder='css', static_url_path='/static')

# 1. ROTA DA PÁGINA INICIAL
@app.route('/')
def index():
    return render_template('index.html')

# 2. ROTA DA PÁGINA SOBRE
@app.route('/about')
def about():
    return render_template('about.html')

# 3. ROTA DA TELA DE LOGIN
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Captura os dados digitados no formulário de login
        nome = request.form.get('usuario', 'Usuário')
        email = request.form.get('email', 'usuario@email.com')
        idade = request.form.get('idade', 'idade')
        peso = request.form.get('peso', 'peso')
        altura = request.form.get('altura', 'altura')
        
        # Redireciona para a página de perfil passando os dados capturados
        return redirect(url_for('profile', nome=nome, email=email, idade=idade, peso=peso, altura=altura))
        
    return render_template('login.html')

# 4. ROTA DO PERFIL DO USUÁRIO (Recebe parâmetros dinâmicos)
@app.route('/profile')
def profile():
    # Coleta os dados enviados pela rota de login ou usa valores padrão
    dados_usuario = {
        'nome': request.args.get('nome', 'nome do usuário'),
        'email': request.args.get('email', 'usuario@email.com'),
        'idade': request.args.get('idade', 'idade'),
        'peso': request.args.get('peso', 'peso'),
        'altura': request.args.get('altura', 'altura')
    }
    
    # Lista de metas estáticas exigida pelo projeto
    metas = [
        "Calcular o IMC mensalmente",
        "Praticar atividade física 3x por semana",
        "Manter uma alimentação balanceada"
    ]
    
    return render_template('profile.html', usuario=dados_usuario, metas=metas)

# 5. ROTA DOS RESULTADOS MATEMÁTICOS
@app.route('/math/<op>/<a>/<b>')
def math(op, a, b):
    try:
        num1 = float(a)
        num2 = float(b)
    except ValueError:
        return "Erro: Os valores informados devem ser números.", 400

    # Dicionário para traduzir o nome e o símbolo da operação
    operacoes = {
        'soma': {'nome': 'Soma', 'simbolo': '+'},
        'subtracao': {'nome': 'Subtração', 'simbolo': '-'},
        'multiplicacao': {'nome': 'Multiplicação', 'simbolo': '×'},
        'divisao': {'nome': 'Divisão', 'simbolo': '÷'}
    }

    if op not in operacoes:
        return "Operação inválida.", 400

    nome_op = operacoes[op]['nome']
    simbolo_op = operacoes[op]['simbolo']
    resultado = 0

    # Realiza o cálculo baseado na operação escolhida
    if op == 'soma':
        resultado = num1 + num2
    elif op == 'subtracao':
        resultado = num1 - num2
    elif op == 'multiplicacao':
        resultado = num1 * num2
    elif op == 'divisao':
        if num2 == 0:
            resultado = "Erro: Divisão por zero não permitida."
        else:
            resultado = round(num1 / num2, 2)

    return render_template('math.html', operacao=nome_op, simbolo=simbolo_op, num1=num1, num2=num2, resultado=resultado)

# 6. ROTA DA CALCULADORA DE IMC e PERCENTUAL DE GORDURA
@app.route('/imc/<peso>/<altura>')
def imc(peso, altura):
    try:
        p = float(peso)
        alt = float(altura)
    except ValueError:
        return "Erro: Peso e altura devem ser valores numéricos.", 400

    if alt <= 0:
        return "Erro: Altura deve ser maior que zero.", 400

    # Captura dados opcionais da URL para o cálculo de gordura corporal
    idade = int(request.args.get('idade', 'idade'))
    sexo = request.args.get('sexo', 'sexo')

    # Cálculo do IMC básico
    valor_imc = round(p / (alt ** 2), 2)
    
    # Classificação do IMC
    if valor_imc < 18.5:
        classe_imc = "Magreza"
        badge_cor = "orange"
    elif valor_imc < 25:
        classe_imc = "Normal"
        badge_cor = "green"
    elif valor_imc < 30:
        classe_imc = "Sobrepeso"
        badge_cor = "yellow"
    else:
        classe_imc = "Obesidade"
        badge_cor = "red"

    # Cálculo do Peso Ideal (Baseado no IMC saudável ideal de 22)
    peso_ideal = round(22 * (alt ** 2), 2)

    # Estimativa de Gordura Corporal pela Fórmula de Deurenberg (1991)
    # Sexo: 1 para homens, 0 para mulheres
    fator_sexo = 1 if sexo.lower() == 'masculino' else 0
    percentual_gordura = round((1.20 * valor_imc) + (0.23 * idade) - (10.8 * fator_sexo) - 5.4, 1)

    return render_template(
        'imc.html', 
        imc=valor_imc, 
        classificacao=classe_imc, 
        cor=badge_cor,
        peso_ideal=peso_ideal, 
        peso=p, 
        altura=alt, 
        idade=idade, 
        sexo=sexo,
        gordura=percentual_gordura
    )

if __name__ == '__main__':
    app.run(debug=True)
