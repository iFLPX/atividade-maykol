from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__, template_folder='template', static_folder='css')
# Chave necessária para ativar o recurso de salvar dados na sessão (Exigência 2)
app.secret_key = 'projeto_fitness_seguro_secret'

# EXIGÊNCIA 1: A tela de login é a primeira tela do site (Rota Raiz)
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # EXIGÊNCIA 2 & 6: Captura e salva TODOS os dados obrigatórios na sessão
        session['usuario'] = request.form.get('usuario', 'Usuário')
        session['email'] = request.form.get('email', 'usuario@email.com')
        session['idade'] = int(request.form.get('idade', 25))
        session['peso'] = float(request.form.get('peso', 70.0))
        session['altura'] = float(request.form.get('altura', 1.75))
        session['sexo'] = request.form.get('sexo', 'Masculino')
        
        # Redireciona para a página de início após o login
        return redirect(url_for('index'))
    
    return render_template('login.html')

# EXIGÊNCIA 3: Página Principal / Início
@app.route('/inicio')
def index():
    if 'usuario' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/sobre')
def about():
    return render_template('about.html')

# EXIGÊNCIA 3: Página de Perfil carregando os dados salvos da sessão
@app.route('/perfil')
def profile():
    if 'usuario' not in session:
        return redirect(url_for('login'))
    return render_template('profile.html')

def calcular_operacao(operacao, num1, num2):
    operacoes = {
        'soma': ('Soma', '+'),
        'subtracao': ('Subtração', '−'),
        'multiplicacao': ('Multiplicação', '×'),
        'divisao': ('Divisão', '÷')
    }

    if operacao not in operacoes:
        return 'Operação inválida', '?', None, 'Selecione uma operação válida.'

    nome, simbolo = operacoes[operacao]
    if operacao == 'divisao' and num2 == 0:
        return nome, simbolo, None, 'Não é possível dividir por zero.'

    if operacao == 'soma':
        resultado = num1 + num2
    elif operacao == 'subtracao':
        resultado = num1 - num2
    elif operacao == 'multiplicacao':
        resultado = num1 * num2
    else:
        resultado = num1 / num2

    resultado = round(resultado, 2)
    if resultado.is_integer():
        resultado = int(resultado)

    return nome, simbolo, resultado, None


@app.route('/calculadora-matematica', methods=['GET', 'POST'])
def math_calculator():
    if request.method == 'GET':
        return render_template('math.html', operacao='soma', num1='', num2='')

    num1 = request.form.get('num1', '').strip()
    num2 = request.form.get('num2', '').strip()
    operacao = request.form.get('operacao', 'soma')

    try:
        valor1 = float(num1)
        valor2 = float(num2)
    except ValueError:
        return render_template(
            'math.html', operacao=operacao, num1=num1, num2=num2,
            erro='Digite dois números válidos.'
        )

    nome_operacao, simbolo, resultado, erro = calcular_operacao(operacao, valor1, valor2)
    return render_template(
        'math.html', operacao=operacao, nome_operacao=nome_operacao,
        num1=num1, num2=num2, simbolo=simbolo, resultado=resultado, erro=erro
    )


# Mantém disponíveis os cálculos por URL usados anteriormente.
@app.route('/math/<op>/<a>/<b>')
def math(op, a, b):
    try:
        num1 = float(a)
        num2 = float(b)
    except ValueError:
        return 'Erro: Os valores informados devem ser números.', 400

    operacao = op.lower()
    nome_operacao, simbolo, resultado, erro = calcular_operacao(operacao, num1, num2)
    if operacao not in ('soma', 'subtracao', 'multiplicacao', 'divisao'):
        return 'Operação inválida.', 400

    return render_template(
        'math.html', operacao=operacao, nome_operacao=nome_operacao,
        num1=a, num2=b, simbolo=simbolo, resultado=resultado, erro=erro
    )

# EXIGÊNCIA 6: Calculadora de IMC com Lógica Avançada (Deurenberg)
@app.route('/calculadora-imc')
def imc_calc():
    if 'usuario' not in session:
        return redirect(url_for('login'))
        
    # Puxa os dados salvos automaticamente ou aceita novos via formulário de recalcular
    peso = float(request.args.get('peso', session.get('peso')))
    altura = float(request.args.get('altura', session.get('altura')))
    idade = int(request.args.get('idade', session.get('idade')))
    sexo = request.args.get('sexo', session.get('sexo'))
    
    # Cálculo do IMC
    imc = round(peso / (altura ** 2), 2)
    
    # EXIGÊNCIA 4: Classificação e definição da cor da barra
    # Vermelho (Abaixo), Verde (Ideal), Azul (Acima / Sobrepeso / Obesidade)
    if imc < 18.5:
        faixa = "Magreza"
        cor_status = "#dc3545" # Vermelho
        posicao_barra = "15%"
        recomendacao = "Aumente o consumo de calorias saudáveis e foque em alimentos ricos em nutrientes."
    elif imc < 25.0:
        faixa = "Normal"
        cor_status = "#198754" # Verde
        posicao_barra = "50%"
        recomendacao = "Excelente! Mantenha seus hábitos alimentares e a prática regular de exercícios."
    elif imc < 30.0:
        faixa = "Sobrepeso"
        cor_status = "#0d6efd" # Azul
        posicao_barra = "70%"
        recomendacao = "Aumente a frequência de atividades físicas e reduza ultraprocessados e açúcares."
    else:
        faixa = "Obesidade"
        cor_status = "#0d6efd" # Azul (Acima do recomendado conforme exigência 4)
        posicao_barra = "90%"
        recomendacao = "Busque orientação de um profissional de saúde para alinhar uma reeducação alimentar."

    # Cálculo do Peso Ideal (Baseado no IMC ideal médio de 21.75)
    peso_ideal = round(21.75 * (altura ** 2), 1)
    
    # Fórmula de Deurenberg para Percentual de Gordura
    fator_sexo = 1 if sexo == 'Masculino' else 0
    gordura = round((1.20 * imc) + (0.23 * idade) - (10.8 * fator_sexo) - 5.4, 1)
    
    # Classificação da Gordura Corporal
    if sexo == 'Masculino':
        if gordura < 6: cat_gordura = "Essencial"
        elif gordura < 14: cat_gordura = "Atlético"
        elif gordura < 18: cat_gordura = "Fitness"
        elif gordura < 25: cat_gordura = "Aceitável"
        else: cat_gordura = "Obesidade"
    else:
        if gordura < 14: cat_gordura = "Essencial"
        elif gordura < 21: cat_gordura = "Atlético"
        elif gordura < 25: cat_gordura = "Fitness"
        elif gordura < 32: cat_gordura = "Aceitável"
        else: cat_gordura = "Obesidade"

    return render_template('imc.html', imc=imc, faixa=faixa, cor=cor_status, 
                           posicao=posicao_barra, peso_ideal=peso_ideal, 
                           gordura=gordura, cat_gordura=cat_gordura, recomendacao=recomendacao,
                           peso=peso, altura=altura, idade=idade, sexo=sexo)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
